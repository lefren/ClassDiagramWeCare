package com.midtrans.sample.data;

public final class Constant {

    public static final String sandboxServerKey = "SB-Mid-server-TOq1a2AVuiyhhOjvfs3U_KeO";
    public static final String sandboxClientKey = "SB-Mid-client-nKsqvar5cn60u2Lv";
    public static final String secondServerKey = "SB-Mid-server-9Nm5c-HJE65AjLNtTX-bRjqm";
    public static final String secondClientKey = "SB-Mid-client-GtbzK39rvs5El-bC";

    public static final String sandboxCreatorKey = "IRIS-330198f0-e49d-493f-baae-585cfded355d";
    public static final String sandboxApproverKey = "IRIS-1595c12b-6814-4e5a-bbbb-9bc18193f47b";

    public static boolean isProduction = false;
}
